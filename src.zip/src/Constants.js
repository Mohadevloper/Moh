module.exports = {
  PREFIX: '!', 
  BALANCE_PRICE: 1000, ////سعر الكوينز
  BALANCE_LOG: '1181080665261883493',///روم تم شراء
  STOCK_CHANNEL: '1181084312792211456', ////روم كمية
  STOCK_MESSAGE: '1181084350931017758',///رسالة الكمية
  CLIENTS_ROLE: '1181083127427383426', //////رتبة شراء عادية
  DONE_CHANNEL: '1181080665261883493', //////روم تم شراء 
  SUPERCLIENTS_ROLE: '1181083082204381194', ////رتبة شراء فخمة
  MIN_MEMBERS: 1,
  RECIPIENT_ID: '852885597601398844',////البنك
  TRANSACTIONS_CHANNEL: '1181081248333041707', ////روم التحويل 
  CLIENT_ID: '1211227204109729863', ////id تبع بوت
  AUTH_URL: 'https://discord.com/oauth2/authorize?client_id=1079846298112499883&response_type=code&redirect_uri=https%3A%2F%2F805f6376-97c3-42d7-865b-7084bb7a0466-00-2hyzfmv69hleb.kirk.replit.dev%2F&scope=identify+guilds+guilds.join',///هنا تحط رابط ادخال الاعضاء
  BOT_URL: 'https://discord.com/api/oauth2/authorize?client_id=1181040789632073778&permissions=8&scope=bot',
  PROBOT_IDS: ['282859044593598464', '567703512763334685'], 
  OWNERS: ['886184496129527848']////الاونر
};